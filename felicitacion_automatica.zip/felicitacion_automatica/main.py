from conexion import conexion
from obtener_cumpleaneros import obtener_cumpleaneros
from crear_pdf import crear_pdf
from enviar_correo import enviar_correo
from datetime import datetime

def main():
    # Conectar a la base de datos
    conect = conexion()

    # Obtener los cumpleañeros
    resultados = obtener_cumpleaneros(conect)
    
    if resultados:
        # Mostrar los cumpleañeros
        for name, anio, email in resultados:
            edad = datetime.now().year - anio
            print(f"Hoy es el cumpleaños de {name} y cumple {edad} años")
            
            pdf_file_name = crear_pdf(name, edad)
            enviar_correo(pdf_file_name, email, name)
    else:
        print("Nadie cumple años hoy")

    # Cerrar la conexión a la base de datos
    conect.close()
    
if __name__ == "__main__":
    main()
