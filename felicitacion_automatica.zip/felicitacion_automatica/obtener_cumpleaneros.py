from datetime import datetime

def obtener_cumpleaneros(conexion):
    fecha_actual = datetime.now()
    cursor = conexion.cursor()

    cursor.execute("SELECT name, anio, email FROM profesores WHERE mes=%s AND dia=%s",(fecha_actual.month, fecha_actual.day,))
    resultados = cursor.fetchall()

    cursor.close()
    return resultados