import mysql.connector

def conexion():
    
    conexion = mysql.connector.connect(user='root', password='', 
                                       host='localhost', 
                                       database='felicitacion_automatica',
                                       port='3307')
    return conexion