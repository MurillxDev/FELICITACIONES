# Función para crear el PDF
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.platypus import Image
from reportlab.lib.units import inch
from datetime import datetime

# Función para crear el PDF
def crear_pdf(name,edad):
    def create_pdf(file_name):
        c = canvas.Canvas(file_name, pagesize=letter)
        c.drawString(100, 750, "FELICIDADES POR TU CUMPLEAÑOS")
        c.drawString(100, 730, f"Fecha y hora de creación: {datetime.now()}")
        #img = Image("D:/Uni/Metodologias de desarrollo/felicitacion_automatica/images/descargar.png", width=3*inch, height=3*inch)
        #img.drawOn(c, 100, 600)
        mensaje = f"¡Hola {name} quiero felicitarte por tus {edad} años que cumples hoy"
        c.drawString(100, 550, mensaje)

        c.save()
        
# Crear el PDF
    pdf_file_name = f"PDFs/{name}.pdf"
    create_pdf(pdf_file_name)

    return pdf_file_name