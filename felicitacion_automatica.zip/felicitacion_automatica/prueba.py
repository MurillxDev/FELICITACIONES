import pdfkit

pdfkit.from_url("https://google.com", "out.pdf")