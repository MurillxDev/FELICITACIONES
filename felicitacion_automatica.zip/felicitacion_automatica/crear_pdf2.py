import jinja2
import pdfkit
from datetime import datetime

# Función para crear el PDF
def crear_pdf2(ruta_template,info):
    nombre_template = ruta_template.split('/')[-1]
    ruta_template = ruta_template.replace(nombre_template,'')
    
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(ruta_template))
    template = env.get_template(nombre_template)
    html = template.render(info)
    
    options = { 'page-size': 'Letter',
               'margin-top': '0.05in',
               'margin-right': '0.05in',
               'margin-buttom': '0.05in',
               'encoding': 'UTF-8'}
    
    ruta_salida = f'D:/Uni/Metodologias de desarrollo/felicitacion_automatica/PDFs/{name}.pdf'
    
    pdfkit.from_string(html,ruta_salida)
       
       
    #return pdf_file_name
       
if __name__ == "__main__":
    ruta_template = "/Uni/Metodologias de desarrollo/felicitacion_automatica/css/template.html"
    name = "Hugo"
    edad = 23
    info = {"name":f"{name}","edad":f"{edad}"}
    pdf_file_name = f"PDFs/{name}.pdf"
    crear_pdf2(ruta_template,info)

    